﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace boxing
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.Clear();
            // Boxing Unboxing .....
            int i = 10;
            object obj = i;//Boxing means Value is convert in to refrence
            Console.WriteLine(obj);
            int j = ((int)obj);// Unboxing opp of boxing
            Console.WriteLine(j);
            Console.Read();
        }
    }
}

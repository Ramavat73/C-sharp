﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace dowhile
{
    class Program
    {
        //Lopping Statement.. Do While...
        static void Main(string[] args)
        {
            Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Clear();
            Console.Write("Enter Any Number:");
            int n = Convert.ToInt32(Console.ReadLine());
            int i = 1;
            int old = 0;
            int New = 0;
            do
            {
                if (i <= 3)
                {
                    Console.WriteLine(i);
                    New = i;
                    old = i - 1;
                }
                else
                {
                    int temp = old * New;
                    if (temp > n)
                    {
                        break;
                    }
                    Console.WriteLine(temp);//temp
                    old = New;
                    New = temp;
                }
                i++;
            } while (i <= n);
            Console.Read();
        }
    }
}

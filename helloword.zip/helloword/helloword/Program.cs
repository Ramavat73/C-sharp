﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace helloword
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.Clear();
            Console.Write("Hello Word");
            Console.Read();
        }
    }
}

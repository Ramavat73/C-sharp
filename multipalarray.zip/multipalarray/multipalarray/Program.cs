﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace multipalarray
{
    class Program
    {
        static void Main(string[] args)
        {
            //one Dimen array
            string[] name = { "Aditya", "Milan", "Akram", "mamu" };
            foreach (string val in name)
            {
                Console.WriteLine(val);
            }
            //Multi dimen array (2d)
            int[,] bick = new int[2,2];
            {
               bick[0,0]=10;
               bick[0, 1] = 20;
               bick[1, 0] = 30;
               bick[1, 1] = 40;
            };
            foreach(int a in bick)
            {
                Console.WriteLine(a);
            }
            //jagged array
            int[][] arr=new int[5][];
            arr[0]=new int[]{11,12,13,14,15};
            arr[1]=new int[]{21,22,23,24,25,26};
            arr[2]=new int[]{31,32,33,34,35,36,37};
            arr[3]=new int[]{41,42,43,44,45,46,47,48};
            arr[4]=new int[]{51,52,53,54,55,56,57,58,59};
            for(int i=0;i<arr.Length;i++)
            {
                for(int j=0;j<arr[i].Length;j++)
                {
                    Console.WriteLine(arr[i][j]+" ");
                }
            }
            Console.WriteLine();
            Console.Read();
        }
    }
}
